# PREM SWARM V2 — Command Nexus

Premium cyberpunk static dashboard for PREM SWARM V2.

## GitHub Pages
Upload `index.html`, `style.css`, and `app.js` to the root of a GitHub repository. Then open **Settings → Pages → Deploy from a branch**, choose the main branch and root folder, and save.

This version is a polished static UI with simulated telemetry. It is deliberately isolated from the Python backend. The next integration step is a small API/WebSocket bridge that exposes RuntimeStateStore, AgentRegistry, EventBus and LearningRecorder as live dashboard data.
